
export class RiderReport {
  rider?: string;
  startDate?: string;
  endDate?: string;
  data?: any;
}